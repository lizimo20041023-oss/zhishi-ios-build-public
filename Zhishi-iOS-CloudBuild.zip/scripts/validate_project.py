from pathlib import Path
import json
import plistlib
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
required = ['Zhishi/ZhishiApp.swift','Zhishi/Info.plist','Zhishi/PrivacyInfo.xcprivacy',
            'Zhishi/Web/index.html','Zhishi/Web/vendor/lucide.min.js','Zhishi/Web/vendor/LUCIDE-LICENSE',
            'Zhishi.xcodeproj/project.pbxproj','Zhishi.xcodeproj/xcshareddata/xcschemes/Zhishi.xcscheme',
            '.github/workflows/ios.yml','scripts/build-unsigned.sh']
for item in required:
    assert (root/item).is_file(), f'Missing {item}'
for item in ['Zhishi/Info.plist','Zhishi/PrivacyInfo.xcprivacy']:
    with (root/item).open('rb') as f: plistlib.load(f)
ET.parse(root/'Zhishi.xcodeproj/xcshareddata/xcschemes/Zhishi.xcscheme')
icons=root/'Zhishi/Assets.xcassets/AppIcon.appiconset'
for icon in json.loads((icons/'Contents.json').read_text(encoding='utf-8'))['images']:
    assert (icons/icon['filename']).is_file()
source=(root/'Zhishi/Web/index.html').read_text(encoding='utf-8')
assert 'window.openai' not in source, 'Preview-only API remains in app bundle'
assert 'window.zhishiStorage' in source
assert 'zhishi:flush' in source
assert '100dvh' in source
assert 'unpkg.com' not in source and 'cdn.jsdelivr.net' not in source
assert not re.search(r'<(?:script|link)[^>]+(?:src|href)=["\']https?://',source)
assert '真实排盘' in source
project=(root/'Zhishi.xcodeproj/project.pbxproj').read_text(encoding='utf-8')
definitions=set(re.findall(r'^\s*(A[0-9A-F]{23}) = \{',project,re.M))
references=set(re.findall(r'\bA[0-9A-F]{23}\b',project))
assert references <= definitions, f'Undefined project references: {references-definitions}'
script=(root/'scripts/build-unsigned.sh').read_bytes()
assert b'\r\n' not in script, 'Build script must use Unix line endings'
print('Project resources, plist/XML, icon references, offline page and build scripts validated.')
print('Xcode compilation and iPhone runtime still require macOS/device verification.')
