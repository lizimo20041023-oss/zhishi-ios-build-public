"""One-time conversion of the approved phone preview into offline app resources."""
from pathlib import Path
import argparse
import json
import re
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('phone_fragment', type=Path)
parser.add_argument('lucide_package', type=Path)
parser.add_argument('font', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
web = root / 'Zhishi' / 'Web'
(web / 'vendor').mkdir(parents=True, exist_ok=True)
source = args.phone_fragment.read_text(encoding='utf-8')
source = source.replace('window.openai', 'window.zhishiStorage')
source = source.replace("'openai:set_globals'", "'zhishi:state_globals'")
source = source.replace('已保存到当前预览会话', '已保存到设备')
source = source.replace('修改保留在本次预览中', '保存失败，请重试')
source = source.replace('本次预览保存', '资料仅存本机')
source = source.replace('交互原型 · 排盘与 AI 待接入', '体验版 · 排盘与 AI 待接入')
source = source.replace('>15800', '>4900000')
source = source.replace('内容较多，修改仅保留在本次打开的预览中', '内容过大，本次修改尚未保存')
source = re.sub(r"if\(f\.dataset\.editing!=='yes'&&state\.profiles\.length>=8\)\{.*?return;\}", '', source)
source = re.sub(r"if\(state\.(?:records|events)\.length>=\d+\)\{toast\('[^']*'\);return;\}", '', source)
source = source.replace('max="2026-10-26"', 'max="${localToday()}"')
source = source.replace('value="2026-10-26"', 'value="${localToday()}"')
source = source.replace('<div class="viz-dotted-background" style="padding:20px 0">', '<div class="zs-native-host">', 1)
injection = """
function localToday(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
let nativeSaveTimer;
root.addEventListener('input',e=>{
  if(e.target.closest('#zs-quicknote')||e.target.id==='zs-reportbody'){
    clearTimeout(nativeSaveTimer);
    nativeSaveTimer=setTimeout(()=>{captureDraft();persist();},400);
  }
});
window.addEventListener('zhishi:flush',()=>{clearTimeout(nativeSaveTimer);captureDraft();persist();});
"""
assert source.count('\nrender();\nconst design=') == 1
source = source.replace('\nrender();\nconst design=', injection+'\nrender();\nconst design=')
native_css = """
html,body{margin:0;padding:0;background:light-dark(#f5f2ea,#211f1b);color-scheme:light dark;-webkit-text-size-adjust:100%}
.zs-native-host{padding:0}
#zhishi-mobile{max-width:none;border:0;border-radius:0;min-height:100dvh;overflow:visible}
#zhishi-mobile .mp-bottom{position:sticky;bottom:0;z-index:5}
#zhishi-mobile .mp-homebar{display:none}
#zhishi-mobile .mp-caption{padding-bottom:10px}
"""
document = '''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="color-scheme" content="light dark">
<meta http-equiv="Content-Security-Policy" content="default-src 'self' data:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'none'; object-src 'none'; base-uri 'none'">
<title>知时</title><script src="vendor/lucide.min.js"></script>
</head><body>'''+source+'<style>'+native_css+'</style></body></html>'
(web / 'index.html').write_text(document, encoding='utf-8')
libraries = list(args.lucide_package.glob('dist/umd/lucide.min.js'))
if not libraries:
    raise SystemExit('Missing local Lucide UMD distribution')
shutil.copyfile(libraries[0], web / 'vendor' / 'lucide.min.js')
license_file = args.lucide_package / 'LICENSE'
if not license_file.is_file():
    raise SystemExit('Missing Lucide license')
shutil.copyfile(license_file, web / 'vendor' / 'LUCIDE-LICENSE')

from PIL import Image, ImageDraw, ImageFont
icon = Image.new('RGB', (1024,1024), '#f5f2ea')
d = ImageDraw.Draw(icon)
d.rounded_rectangle((174,144,850,880), radius=70, fill='#954535')
font = ImageFont.truetype(str(args.font), 540)
bounds=d.textbbox((0,0),'知',font=font)
d.text(((1024-(bounds[2]-bounds[0]))/2-bounds[0],(1024-(bounds[3]-bounds[1]))/2-bounds[1]-5),'知',font=font,fill='#fffaf4')
catalog = root / 'Zhishi' / 'Assets.xcassets'
appicon = catalog / 'AppIcon.appiconset'
appicon.mkdir(parents=True, exist_ok=True)
(catalog / 'Contents.json').write_text(json.dumps({'info':{'author':'xcode','version':1}}),encoding='utf-8')
images=[]
for size,scale in [(20,2),(20,3),(29,2),(29,3),(40,2),(40,3),(60,2),(60,3)]:
    name=f'icon-{size}@{scale}x.png'
    icon.resize((size*scale,size*scale),Image.Resampling.LANCZOS).save(appicon/name)
    images.append({'size':f'{size}x{size}','idiom':'iphone','filename':name,'scale':f'{scale}x'})
icon.save(appicon/'icon-1024.png')
images.append({'size':'1024x1024','idiom':'ios-marketing','filename':'icon-1024.png','scale':'1x'})
(appicon/'Contents.json').write_text(json.dumps({'images':images,'info':{'author':'xcode','version':1}},indent=2),encoding='utf-8')
print('Prepared offline Web bundle, app icons, and local native-storage bridge.')
