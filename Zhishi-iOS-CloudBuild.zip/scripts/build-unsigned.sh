#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This script requires macOS with Xcode. Use the GitHub Actions workflow from Windows." >&2
  exit 1
fi
python3 scripts/validate_project.py
mkdir -p build dist
xcodebuild -version
xcodebuild -project Zhishi.xcodeproj -scheme Zhishi -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= build
app_path="$PWD/build/DerivedData/Build/Products/Release-iphoneos/Zhishi.app"
test -f "$app_path/Zhishi"
test -f "$app_path/Web/index.html"
file "$app_path/Zhishi"
xcrun lipo -verify_arch arm64 "$app_path/Zhishi"
build_staging="$(mktemp -d "$PWD/build/ipa.XXXXXX")"
mkdir -p "$build_staging/Payload"
ditto "$app_path" "$build_staging/Payload/Zhishi.app"
ditto -c -k --sequesterRsrc --keepParent "$build_staging/Payload" "$PWD/dist/Zhishi-unsigned.ipa"
unzip -t dist/Zhishi-unsigned.ipa
shasum -a 256 dist/Zhishi-unsigned.ipa > dist/SHA256SUMS.txt
echo "Built dist/Zhishi-unsigned.ipa. This IPA is unsigned and requires signing before installation."
