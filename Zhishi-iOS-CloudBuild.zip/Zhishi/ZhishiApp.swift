import SwiftUI
import WebKit

@main
struct ZhishiApp: App {
    var body: some Scene {
        WindowGroup { LocalAppView().ignoresSafeArea(.keyboard, edges: .bottom) }
    }
}

struct LocalAppView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> LocalAppController { LocalAppController() }
    func updateUIViewController(_ controller: LocalAppController, context: Context) {}
}

final class LocalAppController: UIViewController, WKNavigationDelegate, WKScriptMessageHandlerWithReply {
    private var webView: WKWebView!
    private var webRoot: URL!
    private let stateURL: URL = {
        let folder = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Zhishi", isDirectory: true)
        return folder.appendingPathComponent("state.json")
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 33/255, green: 31/255, blue: 27/255, alpha: 1)
                : UIColor(red: 245/255, green: 242/255, blue: 234/255, alpha: 1)
        }
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.userContentController.addScriptMessageHandler(self, contentWorld: .page, name: "saveState")
        configuration.userContentController.addUserScript(WKUserScript(
            source: bootstrapScript(), injectionTime: .atDocumentStart, forMainFrameOnly: true
        ))
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.backgroundColor = .clear
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        NotificationCenter.default.addObserver(self, selector: #selector(flushState),
                                               name: UIApplication.willResignActiveNotification, object: nil)
        guard let folder = Bundle.main.url(forResource: "Web", withExtension: nil) else {
            showError("找不到应用页面，请重新安装完整安装包。")
            return
        }
        webRoot = folder.standardizedFileURL
        webView.loadFileURL(folder.appendingPathComponent("index.html"), allowingReadAccessTo: folder)
    }

    private func bootstrapScript() -> String {
        var initial = "null"
        if let data = try? Data(contentsOf: stateURL),
           (try? JSONSerialization.jsonObject(with: data)) != nil,
           let text = String(data: data, encoding: .utf8) { initial = text }
        return """
        window.zhishiStorage = {
          widgetState: \(initial),
          setWidgetState: async function(snapshot) {
            await window.webkit.messageHandlers.saveState.postMessage(JSON.stringify(snapshot));
            this.widgetState = snapshot;
          }
        };
        """
    }

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage,
                               replyHandler: @escaping (Any?, String?) -> Void) {
        guard message.frameInfo.isMainFrame, let text = message.body as? String,
              let data = text.data(using: .utf8), data.count < 5_000_000,
              let parsed = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              parsed["privateContent"] is [String: Any] else {
            replyHandler(nil, "保存内容格式不正确或过大。")
            return
        }
        do {
            try FileManager.default.createDirectory(at: stateURL.deletingLastPathComponent(),
                                                    withIntermediateDirectories: true)
            try data.write(to: stateURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            replyHandler(true, nil)
        } catch { replyHandler(nil, "保存失败，请重试。") }
    }

    @objc private func flushState() {
        webView?.evaluateJavaScript("window.dispatchEvent(new Event('zhishi:flush'))", completionHandler: nil)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url, let webRoot = webRoot else {
            decisionHandler(.cancel); return
        }
        let isLocal = url.isFileURL && url.standardizedFileURL.path.hasPrefix(webRoot.path + "/")
        decisionHandler(isLocal || url.absoluteString == "about:blank" ? .allow : .cancel)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        showError("页面加载失败。请关闭应用后重试。")
    }

    private func showError(_ message: String) {
        let label = UILabel()
        label.text = message
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            label.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24)
        ])
    }
}
