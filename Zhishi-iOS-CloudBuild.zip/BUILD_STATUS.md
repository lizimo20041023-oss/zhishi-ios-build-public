# 构建状态

- 工程：原生 SwiftUI / WKWebView 容器，iPhone，最低 iOS 16。
- 页面：由已确认的知时手机版转成随包离线加载的资源，原预览文件未修改。
- 保存：页面通过 WebKit 消息桥请求原生层将 JSON 原子写入设备的应用目录；启动时读回。
- 已验证：plist/XML 格式、Xcode 工程引用完整性、图标引用、脚本语法、页面无外部请求、离线图标加载、保存接口调用、在新的页面实例恢复手记、390px 手机宽度。
- Web 检查环境：Windows 上的本地 Edge。原生保存层目前由相同接口的模拟实现进行页面侧检查。
- 未验证：Xcode 编译、Swift 原生保存层运行、iOS WebKit 真机效果、IPA 签名与设备安装。
- 当前没有生成 `.ipa`，也没有运行 GitHub Actions。待连接 GitHub 并将本工程上传至仓库后运行 `Build Zhishi IPA`。
- 构建成功后的预期文件：`Zhishi-unsigned.ipa`，需另行签名才能安装。
- 真实八字排盘与 AI 解读尚未实现，当前使用明确标注的演示命盘和解读。
