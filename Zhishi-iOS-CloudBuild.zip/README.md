# 知时 · iPhone 自用版

状态：iOS 工程与云构建配置已准备。本机是 Windows，尚未运行 Xcode，也尚未生成 IPA。

目前包含朋友档案、四柱示例、白话解读示例、看盘手记、朋友反馈、人生事件及可编辑小笺。真实排盘、真太阳时及 AI 解读尚未接入。iOS 16 或更新版本，iPhone 竖屏。

页面和图标均随安装包离线加载，资料由原生层写入设备内的应用目录。退出后重开可恢复；卸载应用可能丢失资料，当前版本还没有备份导出功能。示例档案不对应真实人物或真实生日计算。

## Windows：用 GitHub 云端生成 IPA

1. 在你自己的 GitHub 账号中创建或选择一个仓库。建议使用私有仓库，上传本目录下的全部内容，包含隐藏的 `.github` 目录；不要上传源码 ZIP 本身。仓库根目录应直接看到 `Zhishi.xcodeproj`、`Zhishi`、`scripts` 与 `.github`。
2. 在仓库默认分支打开 **Actions → Build Zhishi IPA → Run workflow**。
3. 成功后，在该次运行页的 **Artifacts** 下载 `Zhishi-unsigned-IPA`，解压后得到 `Zhishi-unsigned.ipa`。
4. 这是未签名安装包。需要使用你自己的签名方式完成签名和设备安装；构建工作流不要求 Apple ID 或证书，也不会提交到 App Store。

私有仓库的 macOS 构建会使用你账号的 Actions 配额，超出额度时是否继续构建取决于账号设置。

## Mac：本机生成未签名 IPA

安装 Xcode 后，在本目录运行：

```bash
bash scripts/build-unsigned.sh
```

输出为 `dist/Zhishi-unsigned.ipa`。也可用 Xcode 打开 `Zhishi.xcodeproj`，选择自己的 Team，设置唯一 Bundle Identifier 后在连接的设备上构建运行。

## 验证范围

准备阶段可在 Windows 验证资源、清单、工程引用及 Web 交互。iOS 编译、WebKit 真机运行与签名安装必须等待 macOS 云构建及设备验证，不能用浏览器检查替代。

## 参考

- [GitHub：手动运行工作流](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow)
- [GitHub：云端 macOS runner](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)
- [Apple：向已注册设备分发应用](https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices)

离线图标使用 Lucide，许可证见 `Zhishi/Web/vendor/LUCIDE-LICENSE`。
